from airflow import DAG
from airflow.operators.http_operator import SimpleHttpOperator
from airflow.operators.python_operator import PythonOperator
from datetime import datetime
import csv
import json

default_args = {
    'owner': 'airflow',
    'start_date': datetime(2023, 6, 12),
}

def extract_data(**kwargs):
    response = kwargs['ti'].xcom_pull(task_ids='get_data')
    data = json.loads(response)
    extracted_data = [(item['postleitzahl'], item['ortbez18']) for item in data]
    return extracted_data

def save_as_csv(**kwargs):
    extracted_data = kwargs['ti'].xcom_pull(task_ids='extract_data')
    filename = '/opt/airflow/data/' + kwargs['execution_date'].strftime('%Y-%m-%d') + '_swisspost_data.csv'
    
    with open(filename, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['Postal Code', 'City'])
        writer.writerows(extracted_data)

with DAG('swisspost_api_to_csv', default_args=default_args, schedule_interval=None) as dag:
    get_data = SimpleHttpOperator(
        task_id='get_data',
        http_conn_id='swisspost_api_conn',
        method='GET',
        endpoint='/plz.json',
        headers={'Accept': 'application/json'},
    )

    extract = PythonOperator(
        task_id='extract_data',
        python_callable=extract_data,
        provide_context=True
    )

    save_csv = PythonOperator(
        task_id='save_as_csv',
        python_callable=save_as_csv,
        provide_context=True
    )

    get_data >> extract >> save_csv

