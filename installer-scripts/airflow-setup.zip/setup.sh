#!/bin/bash
#
# Setup Airflow
#    by 3n3a
#

# original
#    curl -LfO 'https://airflow.apache.org/docs/apache-airflow/2.6.1/docker-compose.yaml'
#



# setup dirs
mkdir -p ./dags ./logs ./plugins ./config ./data
echo -e "AIRFLOW_UID=$(id -u)" > .env

# init db
echo "Now run 'docker compose up airflow-init'"

echo ""
echo "And when finished run with 'docker compose up'"

